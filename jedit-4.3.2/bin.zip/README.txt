QUICK NOTEPAD PLUGIN

The jEdit source distribution includes source code for an example plugin
named 'QuickNotepad', written by John Gellene.

The plugin source is discussed in detail in the 'Writing Plugins' part
of the user's guide.

The source code has been updated to conform the the Plugin API for version 4.0
of jEdit.  The file changes40.txt outlines the changes that were made from the
version distributed with jEdit 3.2.2.

