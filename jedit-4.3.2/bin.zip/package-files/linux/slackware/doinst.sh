( cd usr/share ; rm -rf jEdit )
( cd usr/share ; ln -sf jedit-@jedit.version@ jEdit )
