package com.puppycrawl.tools.checkstyle.javadoc.bothfiles;

class Ignored
{
}
