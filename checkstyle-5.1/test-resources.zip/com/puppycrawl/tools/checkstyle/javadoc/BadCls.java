class BadCls {
  class X extends Exception {}
  void m() throws X {}
}
