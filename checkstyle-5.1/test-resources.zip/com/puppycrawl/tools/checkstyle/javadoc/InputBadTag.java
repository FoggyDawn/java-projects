/**
 * The following is a bad tag.
 * @mytag Hello
 */
public class InputBadTag
{
}
