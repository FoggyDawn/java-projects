/**
 * {@inheritDoc} Where are we inheriting from
 */
package com.puppycrawl.tools.checkstyle.javadoc.pkginfo.invalidinherit;
