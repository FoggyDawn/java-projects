/*
 * (C) '06 incorrect header
 */

package com.puppycrawl.tools.checkstyle.checks.header;

public class H2
{
}
