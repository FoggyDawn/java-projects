/*
 * (C) 2006 correct header
 */

package com.puppycrawl.tools.checkstyle.checks.header;

public class H1
{
}
