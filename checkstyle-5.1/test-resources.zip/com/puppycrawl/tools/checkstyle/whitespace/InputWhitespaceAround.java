public class InputWhitespaceAround
{
    protected InputWhitespaceAround ( int i )
    {
        this ();
        toString ();
    }
    protected InputWhitespaceAround ()
    {
        super ();
    }
}
