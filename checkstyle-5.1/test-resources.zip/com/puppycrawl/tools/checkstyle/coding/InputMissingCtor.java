public class InputMissingCtor
{
}
// we shouln't flag abtract classes
abstract class AbstactClass {
}

// this class has ctor
class CorrectClass {
    CorrectClass() {
    }
}
