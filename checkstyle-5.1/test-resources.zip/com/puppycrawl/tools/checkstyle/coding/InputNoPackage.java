/**
 * No package here.
 */
public class InputNoPackage {
}
