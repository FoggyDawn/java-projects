/*
 * InputBraceAdjustment.java
 *
 * Created on February 21, 2003, 11:21 PM
 */

package com.puppycrawl.tools.checkstyle.indentation;

/**
 *
 * @author  jrichard
 */
public class InputBraceAdjustment 
  {
    
    /** Creates a new instance of InputBraceAdjustment */
    public InputBraceAdjustment() 
      {
        // sorry about the religious commentary... :)
        boolean uglyGnuStyle = true;
        if (uglyGnuStyle)
          {
            System.out.println("ugly GNU style braces");
        }
      }
    
  }
