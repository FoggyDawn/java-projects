/*
 * InputValidDotIndent.java
 *
 * Created on November 24, 2002, 1:22 PM
 */

package com.puppycrawl.tools.checkstyle.indentation;

import javax.
    swing.
        border.
            AbstractBorder;

import javax
    .swing
        .border
            .BevelBorder;
import javax.swing.plaf.metal.MetalButtonUI;

/**
 *
 * @author  jrichard
 */
public class InputValidDotIndent {
    
    /** Creates a new instance of InputValidDotIndent */
    public InputValidDotIndent() {
        
        System.out.println();

        System.
            out.println();
        
        System.out.
            println();
        
        System.
            out.
                println();
        
        System
            .out
                .println();
        
        BevelBorder border = new javax.swing.border.BevelBorder(BevelBorder.LOWERED);
        border = new javax.swing.border.
            BevelBorder(BevelBorder.LOWERED);
        

        border = new javax.swing.border.BevelBorder(
            BevelBorder.LOWERED);
        border = new javax.
            swing.
                border.
                    BevelBorder(BevelBorder.LOWERED);
        border = 
            new javax.
                swing
                    .border
                        .BevelBorder(BevelBorder.LOWERED);
        border = 
            new javax.
                swing
                    .border
                        .BevelBorder(BevelBorder.
                            LOWERED);
        
        Class c = javax.swing.
            plaf.metal.MetalButtonUI.class;
        
        Class c1 = javax.swing
            .plaf.metal.MetalButtonUI.class;
        
        Class c2 = javax.swing
            .plaf.metal.
                MetalButtonUI.class;

        Class c3 = javax.swing
            .plaf.metal
                .MetalButtonUI.class;

        Class c4 = javax.
            swing.plaf.metal.
                MetalButtonUI.class;

        
        
        border = 
            new javax.
                swing
                    .border.BevelBorder(BevelBorder.
                        LOWERED);
        
    }
    
}
