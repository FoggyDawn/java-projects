/*
 * InputCaseLevel.java
 *
 * Created on February 21, 2003, 11:15 PM
 */

package com.puppycrawl.tools.checkstyle.indentation;

/**
 *
 * @author  jrichard
 */
public class InputCaseLevel {
    
    /** Creates a new instance of InputCaseLevel */
    public InputCaseLevel() {
        int test = 4;
        switch (test) {
        case 4: 
            break;
        case 2:
            break;
          default:
            break;
        }
        
        
    }
    
}
