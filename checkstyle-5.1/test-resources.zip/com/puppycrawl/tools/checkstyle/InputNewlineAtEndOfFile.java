////////////////////////////////////////////////////////////////////////////////
// Test case file for checkstyle.
// Created: 2003
////////////////////////////////////////////////////////////////////////////////
package com.puppycrawl.tools.checkstyle;

/**
 * Test case for detection of an existing newline at EOF, using the 
 * NewlineAtEndOfFileCheck.
 * @author Christopher Lenz
 **/
public interface InputNewlineAtEndOfFile
{
}
