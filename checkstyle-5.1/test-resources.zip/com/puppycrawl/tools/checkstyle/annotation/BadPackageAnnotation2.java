@Package//this will not compile in Sun's compiler as of 1.6.0.11
@Metallica
package com.puppycrawl.tools.checkstyle.annotation;


public class BadPackageAnnotation2
{

}
@interface Package {
    
}

@interface Metallica {
    
}
