package blah;

import java.awt.*;

/**
 * Some doc.
 */

public class InputRegexpHeader1
{
}
